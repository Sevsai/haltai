import os
import tkinter as tk
from tkinter import ttk, messagebox, font, filedialog
import time
import json
import openai
from threading import Thread

# Initialize OpenAI with environment variable for security
client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
model_settings = {
    "model": "gpt-4o",
    "temperature": 0.7,
    "top_p": 1,
    "top_k": 50
}

# --- Load Instructions from External JSON File ---
def load_instructions():
    instructions_filepath = "instructions.json"
    if not os.path.exists(instructions_filepath):
        messagebox.showerror("File Error", f"Instructions file '{instructions_filepath}' not found.")
        return None

    with open(instructions_filepath, "r", encoding="utf-8") as file:
        try:
            instructions = json.load(file)
        except json.JSONDecodeError as e:
            messagebox.showerror("File Error", f"Error reading '{instructions_filepath}': {e}")
            return None

    return instructions

# Load the instruction data
instructions_data = load_instructions()
if not instructions_data:
    raise Exception("Failed to load instructions. Exiting...")

# --- GUI Setup ---
root = tk.Tk()
root.title("OpenAI Chat Enhanced")
root.geometry("1800x1000")
root.configure(bg="#1a252f")

# Initialize system_instruction_var AFTER the root window is created
system_instruction_var = tk.StringVar(value=instructions_data["system_instruction"])

# --- Fonts ---
label_font = font.Font(family="Roboto", size=12, weight="bold")
input_font = ("Roboto", 11)
output_font = ("Roboto", 11)

# --- Helper Functions ---
def get_input_text(page_index):
    return input_entries[page_index].get("1.0", tk.END).strip()

def append_to_data_file(prompt, response):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open("data.txt", "a", encoding="utf-8") as file:
        file.write(f"\n--- {timestamp} ---\n--- Prompt ---\n{prompt}\n--- Response ---\n{response}\n")

def handle_generation_error(e):
    progress_bar.stop()
    progress_bar.config(mode="indeterminate")
    messagebox.showerror("Error", f"An error occurred during AI interaction: {e}")

def generate_response(page_index, prompt=""):
    def async_generate():
        input_text = get_input_text(page_index)
        if not input_text:
            messagebox.showwarning("Input Error", "Please enter some text.")
            return

        output_texts[page_index].delete("1.0", tk.END)
        progress_bar.start()
        progress_bar.config(mode="determinate", value=0)

        response_count = response_count_dropdown.get() if multi_response_mode.get() == 1 else 1

        try:
            for _ in range(int(response_count)):
                completion = client.chat.completions.create(
                    model=model_settings["model"],
                    messages=[
                        {"role": "system", "content": system_instruction_var.get()},
                        {"role": "user", "content": prompt + input_text if prompt else input_text}
                    ],
                    temperature=model_settings["temperature"],
                    top_p=model_settings["top_p"],
                    n=1,
                    stream=True
                )

                output = ""
                for chunk in completion:
                    output += chunk.choices[0].delta.content
                    output_texts[page_index].insert(tk.END, chunk.choices[0].delta.content)
                    output_texts[page_index].see(tk.END)
                    root.update_idletasks()
                    progress_bar['value'] += 10

                progress_bar.stop()
                progress_bar.config(mode="indeterminate")

                append_to_data_file(prompt + input_text if prompt else input_text, output)
        except Exception as e:
            handle_generation_error(e)

    Thread(target=async_generate).start()

# --- Button Functions ---
def generate_insights(page_index):
    prompt = instructions_data["button_instructions"]["Insights"]
    generate_response(page_index, prompt)

def generate_contradictions(page_index):
    prompt = instructions_data["button_instructions"]["Contradictions"]
    generate_response(page_index, prompt)

def improve_code(page_index):
    input_text = get_input_text(page_index)
    if not input_text:
        messagebox.showwarning("Input Error", "Please enter some code.")
        return
    prompt = instructions_data["button_instructions"]["Improve"].replace("{input_text}", input_text)
    generate_response(page_index, prompt)

def save_session(page_index):
    session_data = {
        "input": get_input_text(page_index),
        "output": output_texts[page_index].get("1.0", tk.END).strip(),
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    with open(f"session_{page_index + 1}.json", "w", encoding="utf-8") as file:
        json.dump(session_data, file, ensure_ascii=False, indent=4)
    messagebox.showinfo("Session Saved", f"Session {page_index + 1} saved successfully.")

def load_session(page_index):
    filepath = filedialog.askopenfilename(
        defaultextension=".json",
        filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
    )
    if filepath:
        try:
            with open(filepath, "r", encoding="utf-8") as file:
                session_data = json.load(file)
            input_entries[page_index].delete("1.0", tk.END)
            input_entries[page_index].insert(tk.END, session_data['input'])
            output_texts[page_index].delete("1.0", tk.END)
            output_texts[page_index].insert(tk.END, session_data['output'])
        except Exception as e:
            messagebox.showerror("File Error", f"Unable to load session: {e}")

def generate_summary(page_index):
    prompt = instructions_data["button_instructions"]["Generate Summary"]
    generate_response(page_index, prompt)

def translate_text(page_index):
    prompt = instructions_data["button_instructions"]["Translate"]
    generate_response(page_index, prompt)

def add_styling(page_index):
    prompt = instructions_data["button_instructions"]["Add Styling"]
    generate_response(page_index, prompt)

def extract_keywords(page_index):
    prompt = instructions_data["button_instructions"]["Extract Keywords"]
    generate_response(page_index, prompt)

def generate_code_snippet(page_index):
    prompt = instructions_data["button_instructions"]["Generate Code Snippet"]
    generate_response(page_index, prompt)

def analyze_sentiment(page_index):
    prompt = instructions_data["button_instructions"]["Analyze Sentiment"]
    generate_response(page_index, prompt)

def debug(page_index):
    prompt = instructions_data["button_instructions"]["Debug"]
    generate_response(page_index, prompt)

def create_dataset(page_index):
    prompt = instructions_data["button_instructions"]["Create DataSet"]
    generate_response(page_index, prompt)

def review_and_refactor_gui(page_index):
    prompt = instructions_data["button_instructions"]["GUI Enhancement"]
    generate_response(page_index, prompt)

def load_from_file(page_index):
    filepath = filedialog.askopenfilename(
        defaultextension=".txt",
        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
    )
    if filepath:
        try:
            with open(filepath, "r", encoding="utf-8") as file:
                input_text = file.read()
            input_entries[page_index].delete("1.0", tk.END)
            input_entries[page_index].insert(tk.END, input_text)
        except Exception as e:
            messagebox.showerror("File Error", f"Unable to load file: {e}")

def save_to_file(page_index):
    filepath = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
    )
    if filepath:
        try:
            with open(filepath, "w", encoding="utf-8") as file:
                file.write(output_texts[page_index].get("1.0", tk.END))
        except Exception as e:
            messagebox.showerror("File Error", f"Unable to save file: {e}")

def clear_output(page_index):
    output_texts[page_index].delete("1.0", tk.END)

# --- Temperature, Top P, and K Settings ---
def configure_model_settings():
    model_settings["temperature"] = float(temperature_entry.get())
    model_settings["top_p"] = float(top_p_entry.get())
    model_settings["top_k"] = int(top_k_entry.get())
    model_settings["model"] = model_selector.get()
    messagebox.showinfo("Settings Changed", "Model settings have been updated.")

# --- Layout ---
left_frame = tk.Frame(root, bg="#1a252f")
left_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

right_frame = tk.Frame(root, bg="#1a252f")
right_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)

# Configure resizing behavior
root.grid_rowconfigure(0, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)

# Options for system instructions
system_instruction_label = ttk.Label(left_frame, text="System Instructions:", background="#1a252f", foreground="#ecf0f1")
system_instruction_label.pack(pady=5)

system_instruction_entry = ttk.Entry(left_frame, textvariable=system_instruction_var, width=50)
system_instruction_entry.pack(pady=5)

# Create inputs for model settings
settings_frame = tk.Frame(left_frame, bg="#1a252f")
settings_frame.pack(pady=10)

ttk.Label(settings_frame, text="Temperature:", background="#1a252f", foreground="#ecf0f1").grid(row=0, column=0, padx=5)
temperature_entry = ttk.Entry(settings_frame)
temperature_entry.grid(row=0, column=1, padx=5)
temperature_entry.insert(0, "0.7")

ttk.Label(settings_frame, text="Top P:", background="#1a252f", foreground="#ecf0f1").grid(row=1, column=0, padx=5)
top_p_entry = ttk.Entry(settings_frame)
top_p_entry.grid(row=1, column=1, padx=5)
top_p_entry.insert(0, "1")

ttk.Label(settings_frame, text="Top K:", background="#1a252f", foreground="#ecf0f1").grid(row=2, column=0, padx=5)
top_k_entry = ttk.Entry(settings_frame)
top_k_entry.grid(row=2, column=1, padx=5)
top_k_entry.insert(0, "50")

model_selector_label = ttk.Label(settings_frame, text="Select Model:", background="#1a252f", foreground="#ecf0f1")
model_selector_label.grid(row=3, column=0, padx=5, pady=5)
model_selector = ttk.Combobox(settings_frame, values=["gpt-4o-mini", "gpt-4", "gpt-3.5-turbo", "chatgpt-4o-latest", "gpt-4-1106-preview", "gpt-4o"], state="readonly")
model_selector.grid(row=3, column=1, padx=5, pady=5)
model_selector.set(model_settings["model"])  # default model

update_settings_button = ttk.Button(settings_frame, text="Update Settings", command=configure_model_settings)
update_settings_button.grid(row=4, columnspan=2, pady=10)

notebook = ttk.Notebook(left_frame)
notebook.pack(fill="both", expand=True)

# --- Multi Response Mode ---
def toggle_multi_response_mode():
    if multi_response_mode.get() == 1:
        response_count_dropdown.pack(pady=5)
    else:
        response_count_dropdown.pack_forget()

multi_response_mode = tk.IntVar()
multi_response_button = ttk.Checkbutton(right_frame, text="Multi Response Mode", variable=multi_response_mode, onvalue=1, offvalue=0, command=toggle_multi_response_mode)
multi_response_button.pack(pady=15)

response_count_label = ttk.Label(right_frame, text="Select number of responses:", background="#1a252f", foreground="#ecf0f1")
response_count_dropdown = ttk.Combobox(right_frame, values=[1, 2, 3, 4, 5], state="readonly", width=5)
response_count_dropdown.pack_forget()  # Initially hidden
response_count_dropdown.current(0)  # Default to 1

# Create pages (tabs) for multi-session chats
num_pages = 30
input_entries = []
output_texts = []

for i in range(num_pages):
    page = tk.Frame(notebook, bg="#1a252f")
    notebook.add(page, text=f"Page {i + 1}")

    input_frame = tk.Frame(page, bg="#1a252f")
    input_frame.pack(pady=5, padx=10, fill=tk.BOTH, expand=True)
    input_frame.grid_rowconfigure(1, weight=1)
    input_frame.grid_columnconfigure(0, weight=1)

    input_label = ttk.Label(input_frame, text="Input:", font=label_font, background="#1a252f", foreground="#ecf0f1")
    input_label.grid(row=0, column=0, sticky="w")

    input_entry = tk.Text(input_frame, wrap=tk.WORD, font=input_font,
                           background="#34495e", foreground="#ecf0f1", insertbackground="#ecf0f1")
    input_entry.grid(row=1, column=0, sticky="nsew")
    input_entries.append(input_entry)

    # Dropdown menu for additional actions
    actions_menu = tk.Menubutton(page, text="Actions", relief=tk.RAISED, bg="#1a252f", fg="#ecf0f1")
    actions_menu.menu = tk.Menu(actions_menu, tearoff=0)
    actions_menu["menu"] = actions_menu.menu

    button_functions = {
        "Insights": lambda i=i: generate_insights(i),
        "Contradictions": lambda i=i: generate_contradictions(i),
        "Improve": lambda i=i: improve_code(i),
        "Save Session": lambda i=i: save_session(i),
        "Load Session": lambda i=i: load_session(i),
        "Generate Summary": lambda i=i: generate_summary(i),
        "Translate": lambda i=i: translate_text(i),
        "Add Styling": lambda i=i: add_styling(i),
        "Extract Keywords": lambda i=i: extract_keywords(i),
        "Generate Code Snippet": lambda i=i: generate_code_snippet(i),
        "Analyze Sentiment": lambda i=i: analyze_sentiment(i),
        "Debug": lambda i=i: debug(i),
        "Create DataSet": lambda i=i: create_dataset(i),
        "Load": lambda i=i: load_from_file(i),
        "Save": lambda i=i: save_to_file(i),
        "Clear": lambda i=i: clear_output(i),
        "GUI Enhancement": lambda i=i: review_and_refactor_gui(i)
    }

    for button_text, command in button_functions.items():
        actions_menu.menu.add_command(label=button_text, command=command)

    actions_menu.pack(padx=5, pady=5, side=tk.LEFT)

    # Generate button
    generate_button = ttk.Button(page, text="Generate", command=lambda i=i: generate_response(i), width=15, style="TButton")
    generate_button.pack(padx=3, side=tk.LEFT)

    output_frame = tk.Frame(page, bg="#1a252f")
    output_frame.pack(pady=5)
    output_frame.grid_rowconfigure(1, weight=1)
    output_frame.grid_columnconfigure(1, weight=1)

    output_label = ttk.Label(output_frame, text="Output:",
                             font=label_font, background="#1a252f", foreground="#ecf0f1")
    output_label.grid(row=0, column=0, sticky="w")

    output_text = tk.Text(output_frame, wrap=tk.WORD, font=output_font,
                          background="#34495e", foreground="#ecf0f1", insertbackground="#ecf0f1")
    output_text.grid(row=1, column=0, sticky="nsew")
    output_texts.append(output_text)

progress_bar = ttk.Progressbar(root, orient="horizontal", mode="determinate")
progress_bar.grid(row=1, columnspan=2, sticky="ew", padx=5, pady=5)

# --- Load and Save Goals ---
def load_goals():
    if os.path.exists("Updates.txt"):
        with open("Updates.txt", "r", encoding="utf-8") as file:
            return file.read().strip().splitlines()
    return []

def save_goals(goals):
    with open("Updates.txt", "w", encoding="utf-8") as file:
        for goal in goals:
            file.write(f"{goal}\n")

def update_goals():
    current_goals = load_goals()
    new_goal_prompt = "Based on the user needs and AI's interpretation, suggest a new goal:"
    response = generate_response_with_prompt(new_goal_prompt)
    if response:
        current_goals.append(response)
        save_goals(current_goals)
        messagebox.showinfo("Goals Updated", "New goals have been added. You can edit them in Updates.txt.")

def generate_response_with_prompt(prompt):
    try:
        completion = client.chat.completions.create(
            model=model_settings["model"],
            messages=[
                {"role": "system", "content": system_instruction_var.get()},
                {"role": "user", "content": prompt}
            ],
            temperature=model_settings["temperature"],
            top_p=model_settings["top_p"],
            n=1
        )
        return completion.choices[0].message.content.strip()
    except Exception as e:
        handle_generation_error(e)
        return None

# Add button to update goals in the GUI
update_goals_button = ttk.Button(right_frame, text="Update Goals", command=update_goals)
update_goals_button.pack(pady=5)

# --- Run the main loop ---
root.mainloop()